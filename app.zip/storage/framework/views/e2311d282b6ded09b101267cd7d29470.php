<h1><?php echo e($data); ?></h1>
<?php /**PATH C:\laragon\www\satgasppksunitama\resources\views/mail/laporan.blade.php ENDPATH**/ ?>