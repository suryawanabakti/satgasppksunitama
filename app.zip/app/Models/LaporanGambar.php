<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LaporanGambar extends Model
{
    public $table = 'laporan_gambar';
    protected $guarded = ['id'];
}
