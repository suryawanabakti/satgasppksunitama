<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LaporanFile extends Model
{
    public $table = 'laporan_file';
    protected $guarded = ['id'];
}
