<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LaporanVideo extends Model
{
    //
}
