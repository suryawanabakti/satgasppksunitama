<h1>{{ $data }}</h1>
